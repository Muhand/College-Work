/*
-- Query: SELECT * FROM georgescarrentdb.stores
LIMIT 0, 1000

-- Date: 2016-05-24 02:01
*/
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (10,NULL,'Store 1','102 Test Ave','','Staten Island','NY','USA','10302');
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (11,NULL,'Store 2 ','512 Forest Ave',NULL,'Staten Island','NY','USA','10314');
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (12,NULL,'Store 3','829 Test ST',NULL,'Staten Island','NY','USA','10302');
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (13,NULL,'Store 4 ','89 Test Ave',NULL,'Staten Island','NY','USA','10302');
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (14,NULL,'Store 5','98 Forest Ave',NULL,'Staten Island','NY','USA','10314');
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (15,NULL,'Store 6','18 Forest Ave',NULL,'Staten Island','NY','USA','10314');
INSERT INTO `stores` (`ID`,`Image`,`Name`,`FirstStreet`,`SecondStreet`,`City`,`State`,`Country`,`ZipCode`) VALUES (16,NULL,'Store 7','90 Victory Blvd',NULL,'Staten Island','NY','USA','10314');
