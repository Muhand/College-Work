//insert other OpenGL libraries here
#include "rgbpixmap.h"
#define SCENE 2001
RGBpixmap pic;
void myInit()
{
//read in the bitmap for the window view
pic.readBMPFile(�sunset.bmp�);
pic.setTexture(SCENE);
//setup nice perspective calculations
glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
//setup the light
GLfloat lightIntensity[] = {0.9f, 0.9f, 0.9f, 1.0f};
GLfloat lightPosition[]={2.0f,5.0f,8.0f, 0.0f};
glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
//bounding view box
glOrtho(-1, 1, -1, 1, 0.1, 100.0);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
//viewer location and orientation
gluLookAt(1.3,1.3,3,0.3,0.25,0,0.0,1.0,0.0);
}
//draw a wall
void wall(double thickness)
{
glPushMatrix();
glTranslated(0.5,0.5*thickness, 0.5);
glScaled(1.0, thickness, 1.0);
glutSolidCube(1.0);
glPopMatrix();
}
//draw the window as a quad with a pasted bitmap scene
void window()
{
glEnable(GL_TEXTURE_2D); //enable texturing
glBindTexture(GL_TEXTURE_2D, SCENE); //bind scene to next
glPushMatrix(); //shape
glScaled(0.5,0.8,1);
//draw quad with normals and map texture coords to verts
glBegin(GL_QUADS);
glNormal3f(0,0,1);
glTexCoord2f(0,0); glVertex2i(1,0);
glNormal3f(0,0,1);
glTexCoord2f(1,0);glVertex2i(1,1);
glNormal3f(0,0,1);
glTexCoord2f(1,1);glVertex2i(0,1);
glNormal3f(0,0,1);
glTexCoord2f(0,1);glVertex2i(0,0);
glEnd();
glPopMatrix();
glDisable(GL_TEXTURE_2D);
}
void drawScene()
{
wall(0.02);
glPushMatrix();
glRotated(90.0,0.0,0.0,1.0);
wall(0.02);
glPopMatrix();
glPushMatrix();
glRotated(-90.0,1.0,0.0,0.0);
wall(0.02);
glPopMatrix();
glPushMatrix();
glColor3f(1,0,0);
glTranslated(0.1,0.8,0.001);
glRotated(-90.0,0.0,0.0,1.0);
window();
glPopMatrix();
}
void myDisplay(void)
{
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glColor3f(1,1,1);
drawScene();
glFlush();
}
//rotate the view by 10 degrees when mouse clicked
void myMouse(int button, int state, int x, int y)
{
if(state == GLUT_DOWN)
{
if(button == GLUT_LEFT_BUTTON)
{
glRotated(10,1,0,0);
glutPostRedisplay();
}
else if(button == GLUT_RIGHT_BUTTON)
{
glRotated(-10,1,0,0);
glutPostRedisplay();
}
}
}
//exit program when ESC pressed
void myKeyboard(unsigned char key, int x, int y)
{
if(key == 27)
exit(-1);
}
int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB|GLUT_DEPTH);
glutInitWindowSize(800,800);
glutInitWindowPosition(100, 100);
glutCreateWindow(�A Room with a View�);
glutDisplayFunc(myDisplay);
glutKeyboardFunc(myKeyboard);
glutMouseFunc(myMouse);
//turn on the lights
glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0);
glShadeModel(GL_SMOOTH);
glEnable(GL_DEPTH_TEST);
glEnable(GL_NORMALIZE);
glClearColor(0.1f,0.1f,0.1f,0.0f);
glViewport(0,0, 600, 600);
myInit(); //initialize view
glutFullScreen(); //put into fullscreen or comment out
glutMainLoop();
return 1;
}


Creating a curtain.

#define MW 256
#define MH 256
GLfloat Mesh[MH][MW][3]; //make a mesh 256x256 with x,y and z
Vector3 Normals[MW][MH];


Calculate the normals.

Vector3 newell4(GLfloat pt[4][3])
{
Vector3 m;
for(int i = 0; i < 4 ; i++)
{
int next = (i== 3) ? 0 : i + 1;//which index is next?
m.x += (pt[i][1]-pt[next][1])*(pt[i][2]+pt[next][2]);
m.y += (pt[i][2]-pt[next][2])*(pt[i][0]+pt[next][0]);
m.z += (pt[i][0]-pt[next][0])*(pt[i][1]+pt[next][1]);
}
m.normalize();
return m;
}


General mesh for curtains (with sinusoidal wave).

void createMesh()
{
//set Mesh points
float xinc = 2/(float)MH;
float yinc = 2/ (float)MW;
float x = -1;
float y = -1;
//ripple the curtain
for(int i = 0; i < MH; i++)
{
for(int j = 0; j < MW; j++)
{Mesh[i][j][0] = x;
Mesh[i][j][1] = y;
Mesh[i][j][2] = sin(x*10)/5.0;
x+= xinc;
}
y+= yinc;
x = -1;
}
//calculate normals
GLfloat pt[4][3];
for(int i = 0; i < MH-1; i++)
{
for(int j = 0; j < MW-1; j++)
{
pt[0][0] = Mesh[i][j][0];
pt[0][1] = Mesh[i][j][1];
pt[0][2] = Mesh[i][j][2];
pt[1][0] = Mesh[i][j+1][0];
pt[1][1] = Mesh[i][j+1][1];
pt[1][2] = Mesh[i][j+1][2];
pt[2][0] = Mesh[i+1][j+1][0];
pt[2][1] = Mesh[i+1][j+1][1];
pt[2][2] = Mesh[i+1][j+1][2];
pt[3][0] = Mesh[i+1][j][0];
pt[3][1] = Mesh[i+1][j][1];
pt[3][2] = Mesh[i+1][j][2];
Normals[i][j] = newell4(pt);
}
}
}


Draw the curtain in our scene:

void drawMesh()
{
glPushMatrix();
glEnable(GL_TEXTURE_2D);
glBindTexture(GL_TEXTURE_2D, CURTAIN);
for(int i = 0; i < MH-1; i++)
{
for(int j = 0; j < MW-1; j++)
{
glBegin(GL_QUADS);
glNormal3f(Normals[i][j].x,Normals[i][j].y, Normals[i][j].z);
glTexCoord2f(j/(float)MW,i/(float)MH);
glVertex3f(Mesh[i][j][0],Mesh[i][j][1],
Mesh[i][j][2]);
glNormal3f(Normals[i][j+1].x,
Normals[i][j+1].y, Normals[i][j+1].z);
glTexCoord2f((j)/(float)MW,(i+1)/
(float)MH);
glVertex3f(Mesh[i][j+1][0],Mesh[i][j+1][1,
Mesh[i][j+1][2]);
glNormal3f(Normals[i+1][j+1].x,
Normals[i+1][j+1].y,
Normals[i+1][j+1].z);
glTexCoord2f((j+1)/(float)MW,(i+1)/
(float)MH);
glVertex3f(Mesh[i+1][j+1][0],
Mesh[i+1][j+1][1],Mesh[i+1][j+1][2]);
glNormal3f(Normals[i+1][j].x,
Normals[i+1][j].y, Normals[i+1][j].z);
glTexCoord2f((j+1)/(float)MW,(i)/
(float)MH);
glVertex3f(Mesh[i+1][j][0],
Mesh[i+1][j][1],Mesh[i+1][j][2]);
glEnd();
}
}
glDisable(GL_TEXTURE_2D);
glPopMatrix();
}



Assumptions:

#define CURTAIN 2002
pic.readBMPFile(�iris.bmp�);
pic.setTexture(CURTAIN);



Trimming the curtain:
glPushMatrix();
glTranslated(0.2,0.5,0.05);
glScaled(0.1,0.4,0.2);
drawMesh();
glPopMatrix();


1. Complete your window and curtain by adding the right hand side drape and a
curtain rod. The curtain rod can be made by scaling and translating a cylinder in the
same way a cube was scaled and translated to make the walls.
