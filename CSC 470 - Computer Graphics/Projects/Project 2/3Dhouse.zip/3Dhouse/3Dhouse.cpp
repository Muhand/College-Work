
#include <windows.h>
#include <math.h>
#include <fstream>
#include <time.h>
using std::ifstream;
#define ROTATE		0
#define TRANSLATE	1
#define SCALE		2

#include <GL\gl.h>
#include <GL\glu.h>
#include <GL\glut.h>
#include <GL\glaux.h>
#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glut32.lib")
#pragma comment(lib,"glaux.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )

GLuint		texture[14];
GLsizei		windowwidth,windowheight;
GLfloat		rotatex = 0.0,rotatey = 0.0,
			translatex = 0.0,translatez = -10.0,
			scale = 1.0;

GLint		grass[100][100];
GLint		mode = ROTATE;

void DrawSide(GLfloat lwrlftx,GLfloat lwrlfty,GLfloat z,
		GLfloat width, GLfloat height, GLfloat depth,GLint texnum);

void setWindow(float left, float right, float bottom, float top)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(left, right, bottom, top);
}

void setViewport(float left, float right, float bottom, float top)
{
	glViewport(left, bottom,right-left,top-bottom);
}

AUX_RGBImageRec* LoadBMP(char *filename)
{
	ifstream texture;
	texture.open(filename);
	if(texture.fail())
	{
		MessageBox(0,"unable to load texture file","error",MB_OK);
		texture.close();
		return NULL;
	}
	texture.close();
	return auxDIBImageLoad(filename);
}
int LoadTextures()
{
	AUX_RGBImageRec **TextureImage = new AUX_RGBImageRec*[14];


	TextureImage[0] = LoadBMP("clouds.bmp");
	if(TextureImage[0]==NULL)
	{MessageBox(0,"cant load cloud texture","error",MB_OK);return false;}
	TextureImage[1] = LoadBMP("brick.bmp");
	if(TextureImage[1]==NULL)
	{MessageBox(0,"cant load brick texture","error",MB_OK);return false;}
	TextureImage[2] = LoadBMP("roof.bmp");
	if(TextureImage[2]==NULL)
	{MessageBox(0,"cant load roof texture","error",MB_OK);return false;}
	TextureImage[3] = LoadBMP("grass.bmp");
	if(TextureImage[3]==NULL)
	{MessageBox(0,"cant load grass texture","error",MB_OK);return false;}
	TextureImage[4] = LoadBMP("grassf.bmp");
	if(TextureImage[4]==NULL)
	{MessageBox(0,"cant load inside texture","error",MB_OK);return false;}
	TextureImage[5] = LoadBMP("ball.bmp");
	if(TextureImage[5]==NULL)
	{MessageBox(0,"cant load ball texture","error",MB_OK);return false;}
	TextureImage[6] = LoadBMP("pool.bmp");
	if(TextureImage[6]==NULL)
	{MessageBox(0,"cant load pool texture","error",MB_OK);return false;}
	TextureImage[7] = LoadBMP("water.bmp");
	if(TextureImage[7]==NULL)
	{MessageBox(0,"cant load water texture","error",MB_OK);return false;}
	TextureImage[8] = LoadBMP("door.bmp");
	if(TextureImage[8]==NULL)
	{MessageBox(0,"cant load door texture","error",MB_OK);return false;}
	TextureImage[9] = LoadBMP("door1.bmp");
	if(TextureImage[9]==NULL)
	{MessageBox(0,"cant load door texture","error",MB_OK);return false;}
	TextureImage[10] = LoadBMP("window.bmp");
	if(TextureImage[10]==NULL)
	{MessageBox(0,"cant load window texture","error",MB_OK);return false;}
	TextureImage[11] = LoadBMP("window2.bmp");
	if(TextureImage[11]==NULL)
	{MessageBox(0,"cant load window texture","error",MB_OK);return false;}
	TextureImage[12] = LoadBMP("brickgraf.bmp");
	if(TextureImage[12]==NULL)
	{MessageBox(0,"cant load brick texture","error",MB_OK);return false;}
	TextureImage[13] = LoadBMP("scenery.bmp");
	if(TextureImage[13]==NULL)
	{MessageBox(0,"cant load scenery texture","error",MB_OK);return false;}


	for(int t=0;t<14;++t)
	{
		glGenTextures(1,&texture[t]);
		glBindTexture(GL_TEXTURE_2D,texture[t]);
		glTexImage2D(GL_TEXTURE_2D,0,3,TextureImage[t]->sizeX,TextureImage[t]->sizeY,
					0,GL_RGB,GL_UNSIGNED_BYTE,TextureImage[t]->data);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}
	delete[] TextureImage;
	return true;
}

void myInit(void)
{
	srand(time(NULL));
	LoadTextures();
	///make grass array
	for(int g1=0;g1<100;++g1)
		for(int g2 = 0;g2<100;++g2)
			grass[g1][g2] = rand()%10;
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_2D);
	glShadeModel(GL_SMOOTH);
	glMatrixMode(GL_PROJECTION);
	glClearColor(1.0f,1.0f,1.0f,1.0f);
	glColor3f(1.0f,1.0f,1.0f);
	glPointSize(1.0);
	glClearDepth(1.0f);									// Depth buffer setup
	glEnable(GL_DEPTH_TEST);							// Enables depth testing
	glDepthFunc(GL_LEQUAL);								// The type of depth testing to do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really nice perspective calculations
	glLoadIdentity();									// Reset the view
}


void myMouse(int x, int y)
{
}

void myKeyboard(unsigned char Key, int mouseX, int mouseY)
{ 
	switch(Key)
	{
	case 'q':
	case 'Q':
		exit(0);
		break;
	case 'S':
	case 's':
		mode = SCALE;
		break;
	case 'T':
	case 't':
		mode = TRANSLATE;
		break;
	case 'R':
	case 'r':
		mode = ROTATE;
		break;

	};
}
//////////////////
void mySpecKeyboard(int Key, int mouseX, int mouseY)
{ 
	switch(Key)
	{
	case GLUT_KEY_RIGHT:
		switch(mode){
		case ROTATE:rotatey-=3;break;
		case TRANSLATE:translatex-=0.1;break;
		};
		break;
	case GLUT_KEY_LEFT:
		switch(mode){
		case ROTATE:rotatey+=3;break;
		case TRANSLATE:translatex+=0.1;break;
		};
		break;
	case GLUT_KEY_DOWN:
		switch(mode){
		case ROTATE:rotatex-=3;break;
		case TRANSLATE:translatez-=0.1;break;
		case SCALE:scale-=0.1;break;
		};
		break;
	case GLUT_KEY_UP:
		switch(mode){
		case ROTATE:rotatex+=3;break;
		case TRANSLATE:translatez+=0.1;break;
		case SCALE:scale+=0.1;break;
		};
		break;
	};
	if(rotatex<0)rotatex=0;
	else if(rotatex>170)rotatex=170;
	if(scale<=0.0)scale=0.1;
}

//////////////////
void myReshape(GLsizei w,GLsizei h)
{
	if(h == 0)
		h = 1;
	windowwidth = w;
	windowheight = h;

	float ratio = 1.0* w / h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0, 0, w, h);

	gluPerspective(45,ratio,1,1000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0,1.75,-6.0,
				0.0,0.0,-1.0,
			  0.0f,1.0f,0.0f);
}

void myDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear screen and depth buffer
	GLUquadricObj *gluquad,*ball,*pool,*scenery;

	glPushMatrix();
	glLoadIdentity();
	glTranslatef(translatex,-0.8,translatez);
	glRotatef(rotatex,1.0,0.0,0.0);
	glRotatef(rotatey,0.0,1.0,.0.0);
	glScalef(scale,scale,scale);

		//////////////SKY
		glColor3f(1.0,1.0,1.0);
		glTranslatef(0.0,-10.0,0.0);
		gluquad = gluNewQuadric();
		gluQuadricNormals(gluquad, GL_SMOOTH);
		gluQuadricTexture(gluquad, GL_TRUE);
		glBindTexture(GL_TEXTURE_2D,texture[0]);
		gluSphere(gluquad,50,50.0,100.0);
		glTranslatef(0.0,10.0,0.0);
		//////////////SCENERY
		scenery = gluNewQuadric();
		gluQuadricNormals(scenery, GL_SMOOTH);
		gluQuadricTexture(scenery, GL_TRUE);
		glBindTexture(GL_TEXTURE_2D,texture[13]);
			glTranslatef(0.0,3.5,0.0);
			glRotatef(90.0,1.0,0.0,0.0);
		gluCylinder(scenery,40.0,40.0,50.0,50.0,50.0);
			glRotatef(-90.0,1.0,0.0,0.0);
			glTranslatef(0.0,-3.5,0.0);

		//////////////
		//////////////
		///GRASS
		for(GLfloat y=-100.0;y<100.0;y+=1.0)
		{
			for(GLfloat x=-100.0;x<100.0;x+=1.0)
			{
				if(grass[(GLint)y][(GLint)x]<=3)
					glBindTexture(GL_TEXTURE_2D,texture[4]);
				else
					glBindTexture(GL_TEXTURE_2D,texture[3]);
				glBegin(GL_QUADS);
					glTexCoord2f(0.0f, 0.0f); glVertex3f( y,0, x);		// Bottom Left Of The Quad
					glTexCoord2f(1.0f, 0.0f); glVertex3f( y+1,0,x);		// Bottom Right Of The Quad
					glTexCoord2f(1.0f, 1.0f); glVertex3f( y+1, 0,x+1);		// Top Right Of The Quad
					glTexCoord2f(0.0f, 1.0f); glVertex3f( y, 0, x+1);		// Top Left Of The Quad
				glEnd();
			}
		}
		////////////////////
		glBegin(GL_LINES);
			glColor3f(1.0, 0.0, 0.0);glVertex3f(0.0, 0.0, 1.0);glVertex3f(0.0, 0.0, -1.0);
			glColor3f(0.0, 0.0, 1.0);glVertex3f(-1.0, 0.0, 0.0);glVertex3f(1.0, 0.0, 0.0);
			glColor3f(0.0, 1.0, 0.0);glVertex3f(0.0, 1.0, 0.0);glVertex3f(0.0, -1.0, 0.0);
		glEnd();
	glColor3f(1.0,1.0,1.0);

	DrawSide(-2,0, -4, 4, 3 ,0 , 12);	//back
		DrawSide(-2, 0,0, 4, 3, 0, 1);	//front
			DrawSide(2, 0, 0, 4, 3, -4, 1);	//right
				DrawSide(-2, 0, 0, 4, 3, -4, 1);	//left
	//door & windows/////////////////
			/////front
			DrawSide(-0.5, 0.5, 0.01, 1.0, 0.5, 0,8);
			DrawSide(-0.5, 0.0, 0.01, 1.0, 0.5, 0,9);
			DrawSide(-1.8, 1.8, 0.01, 1, 1, 0,11);
			DrawSide( 0.8, 1.8, 0.01, 1, 1, 0,11);
			DrawSide(-1.8, 0.5, 0.01, 1, 1, 0,10);
			DrawSide( 0.8, 0.5, 0.01, 1, 1, 0,10);
			///////////
			///right
				glBindTexture(GL_TEXTURE_2D,texture[10]);
				glBegin(GL_QUADS);
					glTexCoord2f(0.0f, 0.0f); glVertex3f( 2.01, 0.5, -0.5);		// Bottom Left Of The Quad
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 2.01, 0.5, -1.5);		// Bottom Right Of The Quad
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 2.01, 1.5, -1.5);		// Top Right Of The Quad
					glTexCoord2f(0.0f, 1.0f); glVertex3f( 2.01, 1.5, -0.5);		// Top Left Of The Quad
					
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 2.01, 0.5, -2.5);		// Bottom Left Of The Quad
					glTexCoord2f(0.0f, 0.0f); glVertex3f( 2.01, 0.5, -3.5);		// Bottom Right Of The Quad
					glTexCoord2f(0.0f, 1.0f); glVertex3f( 2.01, 1.5, -3.5);		// Top Right Of The Quad
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 2.01, 1.5, -2.5);		// Top Left Of The Quad
				//left
					glTexCoord2f(0.0f, 0.0f); glVertex3f( -2.01, 0.5, -0.5);		// Bottom Left Of The Quad
					glTexCoord2f(1.0f, 0.0f); glVertex3f( -2.01, 0.5, -1.5);		// Bottom Right Of The Quad
					glTexCoord2f(1.0f, 1.0f); glVertex3f( -2.01, 1.5, -1.5);		// Top Right Of The Quad
					glTexCoord2f(0.0f, 1.0f); glVertex3f( -2.01, 1.5, -0.5);		// Top Left Of The Quad
					
					glTexCoord2f(1.0f, 0.0f); glVertex3f( -2.01, 0.5, -2.5);		// Bottom Left Of The Quad
					glTexCoord2f(0.0f, 0.0f); glVertex3f( -2.01, 0.5, -3.5);		// Bottom Right Of The Quad
					glTexCoord2f(0.0f, 1.0f); glVertex3f( -2.01, 1.5, -3.5);		// Top Right Of The Quad
					glTexCoord2f(1.0f, 1.0f); glVertex3f( -2.01, 1.5, -2.5);		// Top Left Of The Quad

				glEnd();

	/////////////////////////////////
	//////ROOF
		glBindTexture(GL_TEXTURE_2D,texture[2]);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-2,3,0);		// Bottom Left Of The Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f(2,3,0);		// Bottom Right Of The Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f(2,3,-4);		// Top Right Of The Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-2,3,-4);		// Top Left Of The Quad
		///////////roof left
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-2,3,-4);		// Bottom Left Of The Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f(-2,3,0);		// Bottom Right Of The Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f(0,5,0);		// Top Right Of The Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f(0,5,-4);		// Top Left Of The Quad
		///////////roof right
			glTexCoord2f(0.0f, 0.0f); glVertex3f(2,3,0);		// Bottom Left Of The Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f(2,3,-4);		// Bottom Right Of The Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f(0,5,-4);		// Top Right Of The Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f(0,5,0);		// Top Left Of The Quad
		glEnd();

		glBegin(GL_TRIANGLES);
	for(int roof=0;roof<2;++roof)
	{
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-2,3,(roof==0)?0:-4);
		glTexCoord2f(0.5f, 1.0f); glVertex3f(0,5,(roof==0)?0:-4);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(2,3,(roof==0)?0:-4);
	}
		glEnd();
	///////MISC
		//////////////BALL
		glColor3f(1.0,1.0,1.0);
		ball = gluNewQuadric();
		gluQuadricNormals(ball, GL_SMOOTH);
		gluQuadricTexture(ball, GL_TRUE);
		glBindTexture(GL_TEXTURE_2D,texture[5]);
		glTranslatef(5.0,0.2,0.0);
		gluSphere(ball,0.2,10.0,10.0);
		glTranslatef(-5.0,-0.2,0.0);
		//////////////

		//////////////POOL
		pool = gluNewQuadric();
		gluQuadricNormals(pool, GL_SMOOTH);
		gluQuadricTexture(pool, GL_TRUE);
		glBindTexture(GL_TEXTURE_2D,texture[6]);
		glTranslatef(-5.0,0.2,0.0);
		glRotatef(90.0,1.0,0.0,0.0);
		gluCylinder(pool,0.5,0.5,0.15,50.0,50.0);
			glBindTexture(GL_TEXTURE_2D,texture[7]);
			gluCylinder(pool,0.49,0.0,0.15,50.0,50.0);
		glRotatef(-90.0,1.0,0.0,0.0);
		glTranslatef(5.0,-0.2,0.0);
		//////////////

	glPopMatrix();
	glutSwapBuffers();
}

void main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(640, 480);
	glutInitWindowPosition(100, 150);
	glutCreateWindow("The Po' Side of Town - 'T'=Translate mode, 'S'=Scale,'R'=Rotate");

	glutDisplayFunc(myDisplay);
	glutIdleFunc(myDisplay);
	glutReshapeFunc(myReshape);
	//glutPassiveMotionFunc(myMouse);
	glutKeyboardFunc(myKeyboard);
	glutSpecialFunc(mySpecKeyboard);
	myInit();
	//glutFullScreen();
	glutMainLoop();
}

void DrawSide(GLfloat lwrlftx,GLfloat lwrlfty,GLfloat z,
		GLfloat width, GLfloat height, GLfloat depth,GLint texnum)
{
		if(texnum>=0)
		{
			glBindTexture(GL_TEXTURE_2D,texture[texnum]);
			glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f); glVertex3f( lwrlftx,lwrlfty, z);		// Bottom Left Of The Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f( lwrlftx+width+depth,lwrlfty,z+depth);		// Bottom Right Of The Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f( lwrlftx+width+depth, lwrlfty+height,z+depth);		// Top Right Of The Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f( lwrlftx, lwrlfty+height, z);		// Top Left Of The Quad
			glEnd();
		}
		else
		{
			glBegin(GL_QUADS);
			glVertex3f( lwrlftx,lwrlfty, z);		// Bottom Left Of The Quad
			glVertex3f( lwrlftx+width,lwrlfty,z+depth);		// Bottom Right Of The Quad
			glVertex3f( lwrlftx+width, lwrlfty+height,z+depth);		// Top Right Of The Quad
			glVertex3f( lwrlftx, lwrlfty+height, z);		// Top Left Of The Quad
			glEnd();
		}

}

