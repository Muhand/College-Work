﻿using System;
using System.Data;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Web.Configuration;

namespace City1
{
    public class City1
    {
        private string _name;
        private string _countryCode;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string CountryCode
        {
            get { return _countryCode; }
            set { _countryCode = value; }
        }

        public List<City1> GetAll()
        {
            List<City1> results = new List<City1>();
            MySqlConnection con = new MySqlConnection("server=localhost;User Id=root;password=monitor;database=world");
            MySqlCommand cmd = new MySqlCommand("SELECT Name,CountryCode FROM City", con);
            using (con)
            {
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                               
                while (reader.Read())
                {
                    City1 newCity = new City1();
                    newCity.Name = (string)reader["Name"];
                    newCity.CountryCode = (string)reader["CountryCode"];
                    results.Add(newCity);
                }
            }
            con.Close();
            return results;
        }
    }
}

